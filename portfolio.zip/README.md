### MY PORTFOLIO

This project was created to practice my HTML and CSS skills as well as show off some of my projects.

**Live version of the app is available [HERE]()**
